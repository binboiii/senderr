from fake_useragent import UserAgent
import logging
import os
import requests
import asyncio
import re
from bs4 import BeautifulSoup as bs, ResultSet
from flask_mysqldb import MySQL
from random import randrange as r
from datetime import date
import random
import os
from flask import Flask, request
from flask import (flash,render_template,redirect,request,session,url_for,)
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InputFile
from aiogram.utils.exceptions import Throttled
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import aiogram.utils.markdown as md
from pathlib import Path
import shutil
from twilio.rest import Client
import time 
import secrets
from datetime import datetime
from shutil import make_archive
import mysql.connector


# key = []
# def keygen():
#     one = secrets.token_hex(4)
#     two = secrets.token_hex(4)
#     three = secrets.token_hex(4)
#     four = secrets.token_hex(4)
#     global key
#     key = f'''{one}-{two}-{three}-{four}'''

teletoken = '5758446300:AAG_NnQDwRRejLyHcYguDGstfb_ZCsGiQ7o'


sleep = time.sleep
now = datetime.now()
cur = now.strftime("%H_%M")
# KEYGEN
key = secrets.token_hex(2)
key1 = secrets.token_hex(2)
key2 = secrets.token_hex(2)
key3 = secrets.token_hex(2)
fullkey = f'''{key}-{key1}-{key2}-{key3}'''

# TWILIO CONFIG 
token = 'ac2430b4626533ee1f413ab40f589c90'
authsid = 'ACd764f107bf2255ab7b21868939330f47'
msgsid = 'MGff9ae8bc73f52a4621f66bac0c76c1fd'
client = Client(authsid, token)

# BOT CONFIG
TOKEN = teletoken
PREFIX = '/!.'
OWNER = '5080127325 '
ANTISPAM = '10'
today = date.today()
d4 = today.strftime("%b-%d-%Y")
bankname = ''
# INITIATE BOT
storage = MemoryStorage()
bot = Bot(token=TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=storage)
# Configure logging
logging.basicConfig(level=logging.INFO)
# BOT INFO
loop = asyncio.get_event_loop()
# GET BOT INFO
bot_info = loop.run_until_complete(bot.get_me())
BOT_USERNAME = bot_info.username
BOT_NAME = bot_info.first_name
BOT_ID = bot_info.id
print('Working...')
# REQUEST HEADERS 
headers = {'User-Agent': 'Mozilla/5.0'}
session = requests.Session()


# MYSQL INFO
mysql_host = 'localhost'
mysql_user = 'root'
mysql_password = '2020Blkout6080!'
mysql_db = 'sms'
# config db
# db = MySQLdb.connect(host=mysql_host,user=mysql_user,passwd=mysql_password,db=mysql_db)
# cur = db.cursor()
# cur.execute("SELECT * FROM users")
# u = cur.fetchall()

# ADD USERS CHAT TO USE BOT
# mysql = MySQL()
verified = []
acl = []
admins = 5080127325

# USER RESET LIST
with open('saved.txt', 'r') as f:
    saved = f.readlines()
    for row in saved:
        slp = row.split('\n')[0]
        verified.append(int(slp))
        f.close()
users = lambda message: message.chat.id not in acl

# GLOBALS 

num_lines = []
valkey = []
genkey = []
binkey = []


numberss = +16185773594,+18083745425,+15412497912

# START COMMAND
@dp.message_handler(commands=['start'], commands_prefix=PREFIX)
async def start(message: types.Message):
    await message.answer_chat_action('typing')
    usrid = message.chat.id
    FIRST = message.from_user.first_name
    MSG = f'''
Welcome {FIRST} 🙍‍♂️, Im {BOT_NAME}

💬<b>MR.SMS</b>💬

<code>SMS SENDER</code>
• /sms ~ <b>Send Bulk US/CANADA SMS Messsages.</b>📲

🏆<code>LEADS</code>🏆

• /gen ~ <b>GENERATE US/CANADA LEADS</b>📠

💵<code>PURCHASE</code>💵

• /activate ~ <b>ACTIVATE YOUR SUBSCRIPTION</b>💰

• /purchase ~ <b>PURCHASE SUBSCRIPTION</b>💰

YOUR CHATID ~ {usrid} '''
    await message.answer(MSG, disable_web_page_preview=True)
    id = message.chat.id
    name = message.chat.username
    db = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cur = db.cursor()
    connection = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cursor = connection.cursor()
    cur.execute("SELECT chatid,chk FROM sms.users WHERE chatid= %s", (str(id),))
    connection.commit()
    us = cur.fetchone()
    if id in acl:
        pass
    else: 
        if str(id) == str(us[0]):
            if str(us[1]) == 'activated':
                acl.append(id)
            elif str(us[1]) == 'activate':
                pass
            else:
                pass
        else:
            pass
        
# • /mrleads ~ <b>GENERATED/VALIDATED US/CANADA LEADS</b>📠
# • /validate ~ <b>VALIDATE US/CANADA LEADS</b>📠
    
# HELP COMMAND
@dp.message_handler(commands=['help'], commands_prefix=PREFIX)
async def help(message: types.Message):
    await message.answer_chat_action('typing')
    msg = ()
    await message.answer(msg, disable_web_page_preview=True)
# CANCEL COMMAND
@dp.message_handler(state='*', commands=['cancel'], commands_prefix=PREFIX)
async def cancel_handler(message: types.Message, state: FSMContext):
    """Allow user to cancel action via /cancel command"""
    current_state = await state.get_state()
    if current_state is None:
        # User is not in any state, ignoring
        return

    # Cancel state and inform user about it
    await state.finish()
    await message.reply('Cancelled.')

#  ADD USERS TO DB
class ADD(StatesGroup):
    chatid = State()
    username = State()
    credits = State()
    sub = State()
    token = State()
@dp.message_handler(state='*', commands=['add'], commands_prefix=PREFIX)
async def add(message: types.Message, state: FSMContext):
    member = message.chat.id
    if member == admins:
        await message.answer_chat_action('typing')
        await ADD.chatid.set()
        await message.answer('Enter Users Chat ID:')
    else:
        await message.answer('You Need To Be Admin For This')
@dp.message_handler(state=ADD.chatid)
async def chatid(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['chatid'] = message.text
    await ADD.next()
    await message.answer(f'''Enter Username: ''')
@dp.message_handler(state=ADD.username)
async def username(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['username'] = message.text

    await ADD.next()
    await message.answer(f'''Enter Credits: ''')
@dp.message_handler(state=ADD.credits)
async def sub(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['credits'] = message.text

    await ADD.next()
    await message.answer(f'''Enter Sub: ''')
@dp.message_handler(state=ADD.sub)
async def added(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['sub'] = message.text
    await ADD.next()
    await message.answer(f'''Enter Auth Token To Generate Key... ''')

@dp.message_handler(state=ADD.token)
async def bank(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as adata:
        adata['token'] = message.text
        if adata['token'] == '00e2-31ce-6354-3357':
            chatid = adata['chatid']
            usernam = adata['username']
            cred = adata['credits']
            sub = adata['sub']
            token = fullkey
            chec = 'activate'
            connection = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
            mySql_insert_query = ("INSERT INTO users (chatid, username,credits, sub, token, chk) VALUES (%s,%s, %s, %s, %s, %s)")
            cursor = connection.cursor()
            cursor.execute(mySql_insert_query,(chatid,usernam,cred,sub,token,chec))
            connection.commit()
            await message.answer(f'''USER {chatid} ADDED TO DB''')
            await message.answer(f'''<b>{usernam}'S KEY ~ </b><code>{fullkey}</code>''')
            cursor.close()
            await state.finish()


# ACTIVATE

class activate(StatesGroup):
    key = State()
    check = State()
@dp.message_handler(commands=['activate'], commands_prefix=PREFIX)
async def vali(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await activate.key.set()
    await message.answer(f'''<b>Enter Telegram Chat ID</b>''')

@dp.message_handler(state=activate.key)
async def chatid(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as acdata:
        acdata['chatid'] = message.text
    id = message.chat.id
    db = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cur = db.cursor()
    connection = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cursor = connection.cursor()
    cur.execute("SELECT chatid FROM sms.users WHERE chatid= %s", (id,))
    connection.commit()
    chek = cur.fetchone()
    try:
        if str(id) == str(chek[0]):
            await message.answer(f'''<b>Enter Purchase Key: </b>''')
            await activate.next()
        else:
            await message.answer(f'''<b>You Do Not Have A Subscription</b>''')
            await state.finish()
    except TypeError:
        await message.answer(f'''<b>You Do Not Have A Subscription</b>''')
        await state.finish()

@dp.message_handler(state=activate.check)
async def sql(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as acdata:
        acdata['key'] = message.text
    key = acdata['key']
    id = message.chat.id
    name = message.chat.username
    await message.answer(f'''<b>Activating Purchase Key</b>''')
    db = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cur = db.cursor()
    connection = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cursor = connection.cursor()
    cur.execute("SELECT token FROM sms.users WHERE chatid= %s", (str(id),))
    connection.commit()
    chek = cur.fetchone()
    sleep(2)
    if str(key) == str(chek[0]):
        cur.close
        cur2 = db.cursor()
        await message.answer(f'<b>Activating Subscription</b>')
        cur2.execute('UPDATE sms.users SET chk="activated" WHERE chatid=%s', (str(id),))
        db.commit()
        cur2.close()
        if id in acl:
            pass
        else:
            db = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
            cur = db.cursor()
            cur.execute("SELECT chatid FROM sms.users WHERE chatid= %s", (id,))
            res = cur.fetchone()
            pos = res
            if pos == 'activated':
                acl.append(pos)
            elif pos == 'activate':
                await message.answer('You Need To /activate You Purchase Key')
            else:
                pass
            await message.answer(f'<b>Succesfully Activate Subscription\nPress /start to continue</b>')
            await state.finish()
    else:
        await message.answer(f'<b>Invalid Purchase Key Message @xynznzx To Purchase</b>')
        await state.finish()

# PURCHASE
@dp.message_handler(commands=['purchase'], commands_prefix=PREFIX)
async def help(message: types.Message):
    await message.answer_chat_action('typing')
    msg = ()
    await message.answer('Message @xynznzx To Purchase Subscription')


# CHECK USERS
@dp.message_handler(users, content_types=['any'])
async def handle_unwanted_users(message: types.Message):
    await message.answer('You Do Not Have Permission To Use This Bot!')
    return


# SEND
class sms(StatesGroup):
    message = State()
    file = State()
    check = State()

@dp.message_handler(commands=['sms'], commands_prefix=PREFIX)
async def mess(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await sms.message.set()
    await message.answer(f'''Enter Message:\n(MAX 250 CHAR)''')

@dp.message_handler(state=sms.message)
async def list(message: types.Document, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as sdata:
        sdata['message'] = message.text


    await message.answer(f'''Enter Leads As .txt File: ''')
    await sms.next()

pull = ''
remain = ''
@dp.message_handler(content_types=types.ContentType.DOCUMENT, state=sms.file)
async def scan_message(message: types.Message, state: FSMContext):
    userpath = message.chat.id
    user = str(message.chat.id)
    async with state.proxy() as sdata:
        sdata['file'] = message.document.file_name
    if not os.path.exists(f'''files/{message.chat.id}/'''):
        os.makedirs(f'''files/{message.chat.id}/''')
    destination = "files/"+str(message.chat.id)+"/"+message.document.file_name
    await message.document.download(destination)
    filelog = "files/"+user+"/"+message.document.file_name
    num_lines = sum(1 for line in open(filelog))
    connection1 = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
    cursor1 = connection1.cursor()
    query = "SELECT credits FROM users WHERE chatid= %s"
    cursor1.execute(query,(user,))
    myresult = cursor1.fetchall()
    for x in myresult:
        global remain
        remain = x[0]
        global pull
        pull = int(x[0]) - num_lines
        if x[0] == 0:
            noo = ('You Have 0 Credits')
            await message.answer(noo)
        elif x[0] == "unlimited":
            pl = (f'''
<code>TEXT = {sdata['message']}</code>

<b>THIS SEND WILL COST {num_lines} CREDITS</b>

<b>REMAINING CREDITS AFTER SEND OUT {pull}</b>

<b>DO YOU WISH TO CONTINUE?? [Y/N]</b>''')
            await sms.next()
            await message.answer(pl)
        else:
            msg = (f'''
<code>TEXT = {sdata['message']}</code>

<b>THIS SEND WILL COST {num_lines} CREDITS</b>

<b>REMAINING CREDITS AFTER SEND OUT {pull}</b>

<b>DO YOU WISH TO CONTINUE?? [Y/N]</b>''')
            await sms.next()
            await message.answer(msg)

@dp.message_handler(state=sms.check)
async def check(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as sdata:
        sdata['val'] = message.text
    await message.answer("Sendout In Progress..")
    user = str(message.chat.id)
    val = sdata['val']
    text = sdata['message']
    file = sdata['file']
    filelog = "files/"+user+"/"+file
    if val.lower() == 'y':
        connection2 = mysql.connector.connect(host='localhost',database=mysql_db,user= mysql_user,password=mysql_password)
        cursor2 = connection2.cursor()
        query1 = 'UPDATE sms.users SET credits=%s WHERE chatid=%s'
        cursor2.execute(query1, (pull, user, ))
        connection2.commit()
        cursor2.close()
        with open(filelog, 'r') as w:
            fdata = w.readlines()
            for line in fdata:
                phone = line
                sleep(2)
                send = client.messages.create(messaging_service_sid= msgsid,body= text,to=phone)
                if send.status == 'accepted':
                    pass
                else:
                    pass
            await message.answer(f'Send Out Finished , {remain} Credits Remaining')
            await message.answer(f'''<code>SUBSCRIPTION ENDING IN 1000 DAYS</code>''')
            await state.finish()
    else:
        pass


# VALIDATOR
class valid(StatesGroup):
    file = State()
    send = State()

@dp.message_handler(commands=['validate'], commands_prefix=PREFIX)
async def vali(message: types.Document, state: FSMContext):
    await message.answer_chat_action('typing')

    await valid.file.set()
    await message.answer(f'''
<b>MR.VALIDATE</b>
Validate Your Leads !!

✅ Mobile - Verified Mobile Number
🟨 Landline - Verified Landline Number
❌ Invalid - Invalid Number''') 
    sleep(.5)
    await message.answer(f'''Enter Leads As .txt File''')

@dp.message_handler(content_types=types.ContentType.DOCUMENT, state=valid.file)
async def scan_message(message: types.Message , state: FSMContext):
    userpath = message.chat.id
    user = str(message.chat.id)
    async with state.proxy() as vdata:
        vdata['file'] = message.document.file_name
    if not os.path.exists(f'''files/{message.chat.id}/'''):
        os.makedirs(f'''files/{message.chat.id}/''')
    destination = "files/"+str(message.chat.id)+"/"+message.document.file_name
    await message.document.download(destination)
    filelog = "files/"+user+"/"+message.document.file_name
    num_lines = sum(1 for line in open(filelog))
    await message.answer(f'''
Validating ({num_lines}) Number's

This May Take A Moment Check Back Soon ..''')
    with open(filelog, 'r') as w:
            fdata = w.readlines()
            if not os.path.exists(f'''db/{user}/validated'''):
                os.makedirs(f'''db/{user}/validated''')
            filepath = (f'''db/{user}''')
            # open(f'db/{user}/Mobile.txt', 'w').close()
            # open(f'db/{user}/Landline.txt', 'w').close()
            # open(f'db/{user}/Invalid.txt', 'w').close()
            for line in fdata:
                data = line.split('\n')[0]
                country = data[0:2]
                area = data[2:5]
                three = data[5:8]
                four = data[8:]
                tog = (country+area+three+four)
                prox = Proxy()
                res = requests.get("https://www.proxy-list.download/api/v1/get?type=http", headers={'User-Agent':'Mozilla/5.0'})
                soup = bs(res.text, features="lxml")
                pip = soup.find('p').text
                ip = pip.split('\n')
                http = random.choice(ip)
                proxy = {'http': http.strip('\r')}
                prox.proxy_type = ProxyType.MANUAL
                prox.http_proxy = str(proxy)
                capabilities = webdriver.DesiredCapabilities.CHROME
                options = Options()
                options.add_argument("--headless")
                head = Service(ChromeDriverManager().install())
                capabilities = webdriver.DesiredCapabilities.CHROME
                prox.add_to_capabilities(capabilities)
                driver = webdriver.Chrome(service= head, options=options, desired_capabilities=capabilities)
                link = f'''http://www.fonefinder.net/findome.php?npa={area}&nxx={three}&thoublock={four}&usaquerytype=Search+by+Number&cityname='''
                fone = driver.get(url= link )
                cont = driver.page_source
                soup = bs(cont, 'html.parser')
                data = soup.text
                if 'Sorry, no records found' in data:
                    o = open(f'''{filepath}/Validated/Invalid.txt''', 'a')
                    o.write('INVALID ~ '+tog+'\n')
                    o.close()
                    pass
                elif '1000' in data:
                    pass
                else:
                    try:
                        dump = re.findall('state=(.+?)"><img',str(soup))[0]
                        pass
                    except IndexError:
                        dump = re.findall('state=(.+?)">',str(soup))[0]
                        pass
                    search = re.findall('.php">(.+?)</td><td><a href="', str(dump))
                    output = str(search)
                    testy = output.replace('[','')
                    post = testy.replace(']','')
                    posty = post.removeprefix("'")
                    final = posty.removesuffix("'")
                    carrier = final.split('</a></td><td>')[0]
                    try:
                        type = final.split('</a></td><td>')[1]
                        pass
                    except IndexError:
                        continue
                    if carrier == None:
                        pass
                        continue
                    else:
                        pass
                    state = re.findall('.gif">(.+?)</a></td><td><a href="http:', str(dump))[0]
                    city = re.findall('cityname=(.+?)&amp;state=',str(dump))[0]
                    city1 = city.replace('+',' ')
                    statepath = state
                    citypath = city1 
                    carrierpath = carrier
                    if type == 'WIRELESS PROV':
                        f = open(f'''{filepath}/validated/Mobile.txt''', 'a')
                        final = (f'''{BOT_NAME} ~ PHONE: {tog} | CARRIER: {carrier} | STATE: {state} | CITY: {city1}''')
                        f.write(final+'\n')
                        f.close 
                    else:
                        l = open(f'''{filepath}/validated/Landline.txt''', 'a')
                        final = (f'''{BOT_NAME} ~ PHONE: {tog} | CARRIER: {carrier} | STATE: {state} | CITY: {city1}''')
                        l.write(final+'\n')
                        l.close
            global valkey
            valkey = secrets.token_hex(3)
            await message.answer(f'''
Enter The 6 Digit Key To Get Leads
<b>CODE:</b> <code>{valkey}</code>''')
            await valid.next()

@dp.message_handler(state=valid.send)
async def scan_message(message: types.Message, state: FSMContext):
    async with state.proxy() as vdata:
        vdata['send'] = message.text
    doc = vdata['file']
    if vdata['send'] == valkey:
        user = str(message.chat.id)
        await message.answer('✅ Validated Mobile Leads....')
        try: 
            mobile = open(f'db/{user}/validated/Mobile.txt', 'rb')
            await message.answer_document(open(mobile.name), 'rb')
            mobile.close()
            pass
        except FileNotFoundError:
            await message.answer('No Mobile Leads Found.')
            pass
        sleep(1)
        await message.answer('🟨 Validated Landline Leads....')
        try:
            landline = open(f'db/{user}/validated/Landline.txt', 'rb')
            await message.answer_document(open(landline.name), 'rb')
            landline.close
        except FileNotFoundError:
            await message.answer('No Landline Leads Found.')
            pass
        sleep(1)
        await message.answer('❌ Invalid Leads....')
        try:
            invalid = open(f'db/{user}/Invalid.txt', 'rb')
            await message.answer_document(open(invalid.name), 'rb')
            invalid.close()
        except:
            await message.answer('No Invalid Leads Found.')
            pass
        try:
            os.remove(f'db/{user}/validated/Mobile.txt')
            pass
        except FileNotFoundError:
            pass
        try:
            os.remove(f'db/{user}/validated/Landline.txt')
            pass
        except FileNotFoundError:
            pass
        try:
            os.remove(f'db/{user}/validated/Invalid.txt')
        except FileNotFoundError:
            pass
        try:
            os.remove(f'files/{user}/{doc}')
            pass
        except FileNotFoundError:
            pass
        await message.answer(f'''<code>SUBSCRIPTION ENDING IN 1000 DAYS</code>''')
    else:
        await message.answer("Wrong Key Try Again..")
        scan_message()
    await state.finish()


#GENERATOR 
class Gen(StatesGroup):
    cu = State()
    ac = State()
    amt = State()

@dp.message_handler(commands=['gen'], commands_prefix=PREFIX)
async def gen(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await Gen.cu.set()
    await message.answer(f'''<b>Enter Country Code without (+): </b>''')

@dp.message_handler(state=Gen.cu)
async def cu(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['cu'] = message.text

    await Gen.next()
    await message.answer(f'''<b>Enter Area Code: </b>''')

@dp.message_handler(state=Gen.ac)
async def ac(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['ac'] = message.text

    await Gen.next()
    await message.answer(f'''<b>How Many Leads?: </b>''')

@dp.message_handler(state=Gen.amt)
async def amt(message: types.Message, state: FSMContext):
    user = str(message.chat.id)
    if not os.path.exists(f'''db/{user}/gen'''):
        os.makedirs(f'''db/{user}/gen''')
    filepath = (f'''db/{user}/gen/''')
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        name = message.from_user.username
        data['amt'] = message.text

        countrycode = data['cu']
        areacode = data['ac']
        amount = (data['amt'])
        ammt = int(amount)
        time.sleep(5)
        for number in range(ammt):
            city = (random.randint(200,999))
            last = (random.randint(1000,9999))
            number = ("+"+countrycode+areacode+str(city)+str(last)+'\n')
            filename = filepath+name+'-('+areacode+')leads.txt'
            f = open(filename, 'a')
            f.write(number)
            f.close()
    await state.finish()
    try:
        await message.answer_document(open(filename, 'rb'))
        pass
    except FileNotFoundError:
        await message.answer('Could Not Get Leads Try Again Later...')
        pass
    try:
        os.remove(filename)
        pass
    except FileNotFoundError:
        pass

# GEN/VAL
class Form(StatesGroup):
    cc = State()
    ac = State()
    amt = State()
    send = State()

@dp.message_handler(commands=['mrleads'], commands_prefix=PREFIX)
async def tmo(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')

    await Form.cc.set()
    await message.answer(f'''<b>Enter Country Code without (+): </b>''')

@dp.message_handler(state=Form.cc)
async def tmocc(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['cc'] = message.text

    await Form.next()
    await message.answer(f'''<b>Enter Area Code: </b>''')

@dp.message_handler(state=Form.ac)
async def tmac(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['ac'] = message.text
    await message.answer(f'''<b>How Many Leads Do You Want To Parse Thru? (1000 MAX)</b>''')

    await Form.next()

@dp.message_handler(state=Form.amt)
async def tmac(message: types.Message, state: FSMContext):
    await message.answer_chat_action('typing')
    async with state.proxy() as data:
        data['amt'] = message.text
    user = str(message.chat.id)
    if not os.path.exists(f'''db/{user}/genval'''):
        os.makedirs(f'''db/{user}/genval''')
    filepath = (f'''db/{user}/genval/''')
    country = data['cc']
    area = data['ac']
    if data['amt'] <= '1000':
        await message.answer('This May Take A Few Minutes .. ⏰')
        for poll in range(int(data['amt'])):
            three = random.randrange(100,999)
            four = random.randrange(1000,9999)
            tog = (str(country)+str(area)+str(three)+str(four))
            prox = Proxy()
            res = requests.get("https://www.proxy-list.download/api/v1/get?type=http", headers={'User-Agent':'Mozilla/5.0'})
            soup = bs(res.text, features="lxml")
            pip = soup.find('p').text
            ip = pip.split('\n')
            http = random.choice(ip)
            proxy = {'http': http.strip('\r')}
            prox.proxy_type = ProxyType.MANUAL
            prox.http_proxy = str(proxy)
            capabilities = webdriver.DesiredCapabilities.CHROME
            options = Options()
            options.add_argument("--headless")
            head = Service(ChromeDriverManager().install())
            capabilities = webdriver.DesiredCapabilities.CHROME
            prox.add_to_capabilities(capabilities)
            driver = webdriver.Chrome(service= head, options=options, desired_capabilities=capabilities)
            link = f'''http://www.fonefinder.net/findome.php?npa={area}&nxx={three}&thoublock={four}&usaquerytype=Search+by+Number&cityname='''
            fone = driver.get(url= link )
            cont = driver.page_source
            soup = bs(cont, 'html.parser')
            data = soup.text
            if 'Sorry, no records found' in data:
                o = open(f'''{filepath}/Invalid.txt''', 'a')
                o.write('INVALID ~ '+tog)
                o.close()
                pass
            elif '1000' in data:
                pass
            else:
                try:
                    dump = re.findall('state=(.+?)"><img',str(soup))[0]
                    pass
                except IndexError:
                    dump = re.findall('state=(.+?)">',str(soup))[0]
                    pass
                search = re.findall('.php">(.+?)</td><td><a href="', str(dump))
                output = str(search)
                testy = output.replace('[','')
                post = testy.replace(']','')
                posty = post.removeprefix("'")
                final = posty.removesuffix("'")
                carrier = final.split('</a></td><td>')[0]
                try:
                    type = final.split('</a></td><td>')[1]
                    pass
                except IndexError:
                    continue
                if carrier == None:
                    continue
                else:
                    pass
                state = re.findall('.gif">(.+?)</a></td><td><a href="http:', str(dump))[0]
                city = re.findall('cityname=(.+?)&amp;state=',str(dump))[0]
                city1 = city.replace('+',' ')
                statepath = state
                citypath = city1 
                carrierpath = carrier
                if type == 'WIRELESS PROV':
                    f = open(f'''{filepath}/Mobile.txt''', 'a')
                    final = (f'''{BOT_NAME} ~ PHONE: {tog} | CARRIER: {carrier} | STATE: {state} | CITY: {city1}''')
                    f.write(final+'\n')
                    f.close 
                else:
                    l = open(f'''{filepath}/Landline.txt''', 'a')
                    final = (f'''{BOT_NAME} ~ PHONE: {tog} | CARRIER: {carrier} | STATE: {state} | CITY: {city1}''')
                    l.write(final+'\n')
                    l.close
        global genkey
        genkey = secrets.token_hex(3)
        await message.answer(f'''
Enter The 6 Digit Key To Get Leads
<b>CODE:</b> <code>{genkey}</code>''')
        await Form.next()

    else:
        await message.answer('Too Many Leads..')
        await message.answer('Try Again.. /mrleads')

@dp.message_handler(state=Form.send)
async def scan_message(message: types.Message, state: FSMContext):
    async with state.proxy() as bdata:
        bdata['send'] = message.text
    if bdata['send'] == genkey:
        user = str(message.chat.id)
        await message.answer('✅ Validated Mobile Leads....')
        try: 
            mobile = open(f'db/{user}/genval/Mobile.txt', 'rb')
            await message.answer_document(open(mobile.name), 'rb')
            mobile.close()
            pass
        except FileNotFoundError:
            await message.answer('No Mobile Leads Found.')
            pass
        sleep(1)
        await message.answer('🟨 Validated Landline Leads....')
        try:
            landline = open(f'db/{user}/genval/Landline.txt', 'rb')
            await message.answer_document(open(landline.name), 'rb')
            landline.close
        except FileNotFoundError:
            await message.answer('No Landline Leads Found.')
            pass
        sleep(1)
        await message.answer('❌ Invalid Leads....')
        try:
            invalid = open(f'db/{user}/genval/Invalid.txt', 'rb')
            await message.answer_document(open(invalid.name), 'rb')
            invalid.close()
        except:
            await message.answer('No Invalid Leads Found.')
            pass
        try:
            os.remove(f'db/{user}/genval/Mobile.txt')
            pass
        except FileNotFoundError:
            pass
        try:
            os.remove(f'db/{user}/genval/Landline.txt')
            pass
        except FileNotFoundError:
            pass
        try:
            os.remove(f'db/{user}/genval/Invalid.txt')
        except FileNotFoundError:
            pass
        await message.answer(f'''<code>SUBSCRIPTION ENDING IN 1000 DAYS</code>''')
    else:
        await message.answer("Wrong Key Try Again..")
        scan_message()
    await state.finish()


# BIN SORTER
class sort(StatesGroup):
    file = State()
    send = State()

@dp.message_handler(commands=['sorter'], commands_prefix=PREFIX)
async def filee(message: types.Document, state: FSMContext):
    await message.answer_chat_action('typing')

    await sort.file.set()
    await message.answer(f'''<b>Enter BIN List</b>''')

@dp.message_handler(content_types=types.ContentType.DOCUMENT, state=sort.file)
async def binlist(message: types.Message , state: FSMContext):
    userpath = message.chat.id
    user = str(message.chat.id)
    async with state.proxy() as qdata:
        qdata['file'] = message.document.file_name
    if not os.path.exists(f'''files/{message.chat.id}/'''):
        os.makedirs(f'''files/{message.chat.id}/''')
    destination = "files/"+str(message.chat.id)+"/"+message.document.file_name
    await message.document.download(destination)
    filelog = "files/"+user+"/"+message.document.file_name
    num_lines = sum(1 for line in open(filelog))
    await message.answer(f'''<b>Getting Bank List</b>''')
    if not os.path.exists(f'''db/{user}/binlist'''):
        os.makedirs(f'''db/{user}/binlist''')
    filee = f'''db/{user}/binlist/'''
    with open(filelog, 'r') as w:
        data = w.readline().split(' ')
        for line in data:
            binny = line.split('+')[0]
            s = requests.Session()
            url = 'https://www.bankbinlist.com/search.html?bin='+binny
            r = s.get(url)
            soup = bs(r.text, 'html.parser')
            table = soup.find("table", class_="table text-left")
            # td = table.find_all('td')
            list = [td.get_text() for td in soup.find_all('td')]
            info = list[7:]
            inf = info[:-7]
            int = inf[0:]
            country = int[0:1]
            cur = inf[2:3]
            bank = inf[3:4]
            site = inf[4:5]
            banknum = inf[5:6]
            brand = inf[7:8]
            type = inf[8:9]
            sub = inf[9:10]
            prepaid = inf[-1:0]
            com = inf[-2:0]
            finn = f'''BIN ~ {binny} | BANK ~ {bank} | BRAND ~ {brand} | TYPE ~ {type} | SUBTYPE ~ {sub} | COUNTRY ~ {country}'''
            test = f'''db/{user}/binlist/{str(bank)}.txt'''
            try: 
                f = open(test, 'a')
                pass
            except FileNotFoundError:
                pass
            try:
                f.write(finn+'\n')
                pass
            except FileNotFoundError:
                pass
        global binkey
        binkey = secrets.token_hex(3)
        await message.answer(f'''
Enter The 6 Digit Key To Get Leads
<b>CODE:</b> <code>{binkey}</code>''')
        await sort.next()

@dp.message_handler(state=sort.send)
async def sendeee(message: types.Message, state: FSMContext):
    async with state.proxy() as pdata:
        pdata['send'] = message.text
    if pdata['send'] == binkey:
        user = str(message.chat.id)
        zipfile = f'{user}_binlist'
        folderpath_archive = f'db/{user}/binlist/'
        folderpath_to_zip_up = f'db/{user}/binlist/'
        make_archive(os.path.join(folderpath_archive, zipfile), 'zip', folderpath_to_zip_up)
        binn = f'db/{user}/binlist/{zipfile}.zip'
        await bot.send_document(chat_id=user, document=open(binn, 'rb'))
        os.remove(binn)
        shutil.rmtree(f'db/{user}/binlist/')
        await message.answer(f'''<code>SUBSCRIPTION ENDING IN 1000 DAYS</code>''')
        await state.finish()
    else:
        await message.answer("Wrong Key Try Again..")
        sendeee()
        pass


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True, loop=loop),